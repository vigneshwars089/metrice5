// load math.js\
var express = require('express');
var Excel = require('exceljs');

var app = express();
var parseXlsx = require('excel');

		var http = require('http');
var math = require('mathjs');

// functions and constants
app.get('/', function(req, res) {
	var serverObject = {};
	serverObject.round = math.round(math.e, 3);            // 2.718
	serverObject.atan2 = math.atan2(3, -3) / math.pi;      // 0.75
	serverObject.log = math.log(10000, 10);              // 4
	serverObject.sqrt = math.sqrt(-4);                    // 2i
	serverObject.pow = math.pow([[-1, 2], [3, 1]], 2);   // [[7, 0], [0, 7]]
	serverObject.derivative = math.derivative('x^2 + x', 'x');  // 2 * x + 1
    res.send(serverObject);
});

// expressions
math.eval('12 / (2.3 + 0.7)');    // 4
math.eval('12.7 cm to inch');     // 5 inch
math.eval('sin(45 deg) ^ 2');     // 0.5
math.eval('9 / 3 + 2i');          // 3 + 2i
math.eval('det([-1, 2; 3, 1])');  // -7

// chaining
math.chain(3)
    .add(4)
    .multiply(2)
    .done(); // 14


		// parseXlsx('new.xlsx', '2', function(err, data) {
		//   if(err) throw err;
		// 	// console.log(data);
		//     // data is an array of arrays
		// });

// 		var options = {
//     filename: 'new.xlsx',
//     useStyles: true,
//     useSharedStrings: true
// };
// var workbook = new Excel.stream.xlsx.WorkbookWriter(options);
// 		var worksheet = workbook.getWorksheet(1);
		// console.log(worksheet);

		// read from a file
// var recarr=[];


	var recarray=[];
	var rechead=[];
	var workbook = new Excel.Workbook();
	workbook.xlsx.readFile("new1.xlsx")
	    .then(function() {
				var worksheet = workbook.getWorksheet(1);
				var head=worksheet.getColumn(1);
				var a=2;
				var c="A";
				while(worksheet.getCell(c+"1").value!=null){
					var dynam=[];
					var head=worksheet.getCell(c+"1").value;
				rechead.push(worksheet.getCell(c+"1").value);
				// rechead.push(worksheet.getCell(c+"1").value);
				// console.log(rechead);
				var dobCol = worksheet.getColumn(c);
				var i=0;
				var obj={};
				dobCol.eachCell(function(cell, rowNumber) {
					dynam.push(cell.value);

					// recarray[i][head]=cell.value;
					i++;
				});
				dynam.shift();
				recarray.push(dynam);
				// console.log(recarray);
				c=String.fromCharCode(c.charCodeAt(0) + 1);
				}
	      // console.log(worksheet.getCell("A"+a).value);
				// while (worksheet.getCell("A"+a)!="" && worksheet.getCell("B"+a)!="") {
				// 	var recobject={};
				// 	recobject.x=worksheet.getCell("A"+a).value;
				// 	recobject.y=worksheet.getCell("B"+a).value;
				//
				// 	// var c=m.add(n);
				//
				// 	// var c=math.chain(m)
				// 	//     .add(n)
				// 	// 		.done();
				// 	// console.log(c);
				// 	a++;
				// 	recarray.push(recobject);
				// }
	    });
			app.all('/*', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
});
app.get('/header', function(req, res) {
res.send(rechead);
});
			app.get('/new/:id/:left/:right/:operations/:fields', function(req, res) {
				// console.log(req.params.id);
				// console.log(res);
				var oparray=req.params.operations;
				var fieldarray=req.params.fields;
				// console.log(req.params.operations);
				var operation=req.params.id;
				var header1=req.params.left;
				var header2=req.params.right;
				var i=0;
				var j=0;
				var result=[];
				var resultarray1={};
				var valuearray=[];
				resultarray1['headers']=rechead;	//resultarray1.headers=[a,b,c]
				// console.log(recarray);
				// while (j<) {
				//
				// }
				// console.log(fieldarray);
				while (j<fieldarray.length) {
					// console.log("hai");
					var m=0;

					while(m<resultarray1.headers.length)
					{
					if (fieldarray[j]==resultarray1.headers[m]) {
						valuearray.push(recarray[m]);
						break;
					}
					m++;
				}
				j++;
					// if (header2==resultarray1.headers[j]) {
					// 	resultarray1.b=recarray[j];
					// }
				}
				console.log(valuearray);
				var i=0;
				var myoparray=[];
				var n=0;
				while(n<oparray.length)
				{
					myoparray.push(oparray[n]);
					n=n+2;
				}
				// for (var m = 0; m < oparray.length; m+2) {
				// 	myoparray.push(oparray[m]);
				// }
				var myarray=valuearray;
				console.log(myoparray.length);
				while (i<myoparray.length) {

					// console.log(oparray[i]);
					myarray[i+1]=calcswitch(myarray[i],myarray[i+1],myoparray[i]);
					i++;
				}
				// valuearray.push(myarray[i]);
				console.log(valuearray);
				// var mine=calcswitch(valuearray[0],valuearray[1],operation);

				i=0;
				j=0;
				while (j<resultarray1.headers.length) {
					// console.log("hai");
					if (header1==resultarray1.headers[j]) {
						resultarray1.a=recarray[j];
					}
					if (header2==resultarray1.headers[j]) {
						resultarray1.b=recarray[j];
					}
					j++;
				}
				switch(operation){
				case "1":
				var resultarray=[];
				var resultobject=[];
				while (i<resultarray1['a'].length) {
					 var c=math.chain(resultarray1['a'][i])
					.add(resultarray1['b'][i])
					.done();
					resultobject.push(c);
					i++;
				}
				resultarray1['result']=resultobject;
				console.log(resultarray1);
				break;
				case "2":
				var resultarray=[];
				var resultobject=[];
				while (i<resultarray1['a'].length) {
					 var c=math.chain(resultarray1['a'][i])
					.subtract(resultarray1['b'][i])
					.done();
					resultobject.push(c);
					i++;
				}
				resultarray1['result']=resultobject;
				console.log(resultarray1);
				break;
				case "3":
				var resultarray=[];
				var resultobject=[];
				while (i<resultarray1['a'].length) {
					 var c=math.chain(resultarray1['a'][i])
					.multiply(resultarray1['b'][i])
					.done();
					resultobject.push(c);
					i++;
				}
				resultarray1['result']=resultobject;
				console.log(resultarray1);
				break;
				case "4":
				var resultarray=[];
				var resultobject=[];
				while (i<resultarray1['a'].length) {
					 var c=math.chain(resultarray1['a'][i])
					.divide(resultarray1['b'][i])
					.done();
					resultobject.push(c);
					i++;
				}
				resultarray1['result']=resultobject;
				console.log(resultarray1);
				break;
default:
console.log("Metrics Input Error");
break;
				}

				// res.setHeader('Access-Control-Allow-Credentials', true);

				// Pass to next layer of middleware
				// next();
				res.send(resultarray1);

			});
			function calcswitch(a,b,p) {
				var i=0;
				switch(p){
				case "1":
				var resultobject=[];
				console.log("add");
				console.log(a.length);
				while (i<a.length) {
					 var c=math.chain(a[i])
					.add(b[i])
					.done();
					resultobject.push(c);
					i++;
				}
				// console.log(resultobject);
				break;

				case "2":
				var resultobject=[];
				while (i<a.length) {
					 var c=math.chain(a[i])
					.subtract(b[i])
					.done();
					resultobject.push(c);
					i++;
				}
				break;

				case "3":
				var resultobject=[];
				console.log("subtract");
				while (i<a.length) {
					 var c=math.chain(a[i])
					.multiply(b[i])
					.done();
					resultobject.push(c);
					i++;
				}
				break;

				case "4":
				var resultobject=[];
				while (i<a.length) {
					 var c=math.chain(a[i])
					.divide(b[i])
					.done();
					resultobject.push(c);
					i++;
				}
				break;
default:
console.log("Metrics Input Error");
break;
				}
				return resultobject;

			}

		app.listen(8080);
		console.log('Listening on port 8080...');


// http.createServer(function (req, res) {
//     res.writeHead(200, {'Content-Type': 'text/plain'});
//     res.end('Hello World!');
// }).listen(8080);
