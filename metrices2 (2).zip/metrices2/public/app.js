var app=angular.module('App', ['ngMaterial','ngAnimate','ngMessages']);
// var app1=angular.module('main'['ui.router'])
// app1.config(function($stateProvider,$urlRouterProvider) {


app.controller('demoController', function($scope,$http) {

  $scope.user = null;
$scope.users = null;
$scope.operations =[
  { id: 1, name: 'Addition' },
  { id: 2, name: 'Subtraction' },
  { id: 3, name: 'Multiplication' },
  { id: 4, name: 'Division' }
];
 $scope.fields = [];
  $http.get('http://localhost:8080/header').then(function(data){
    $scope.header=data.data;
  });
$scope.loadoperation = function() {
  $scope.operationfield=[];
  $scope.operation=[];
  $scope.operationfield.push($scope.lefthead);
  $scope.operationfield.push($scope.righthead);
  $scope.operation.push($scope.currentop.id);
  for (var i = 0; i < $scope.fields.length; i++) {
    $scope.operation.push($scope.resop[i].id);
    $scope.operationfield.push($scope.resvar[i]);
    // $scope.operationfield.push();
  }
  console.log($scope.operation);
  console.log($scope.operationfield);
  $http.get('http://localhost:8080/new/'+$scope.currentop.id+'/'+$scope.lefthead+'/'+$scope.righthead+'/'+$scope.operation+'/'+$scope.operationfield).then(function(data) {
    console.log(data.data);
    $scope.myrecord=data.data;
    var a=[];
    a=$scope.myrecord['a'];
    console.log(a);
    var b=[];
    b=$scope.myrecord['b'];
    var c=[];
    c=$scope.myrecord['result'];
    $scope.viewdata=[];
    for (var i = 0; i < a.length; i++) {
      var viewobj={};
      viewobj.a=a[i];
      viewobj.b=b[i];
      viewobj.c=c[i];
      $scope.viewdata.push(viewobj);
    }
    // console.log($scope.viewdata);

    // $scope.tooltipFunc = function(branch) {
    // 	return branch.name;
    // };
        // $scope.myStyle="width:150px;height:100px;"
      });

};
$scope.resop = [];
$scope.resvar=[];

$scope.addField = function() {
  console.log("run");
  var len= $scope.fields.length;
$scope.fields.push({id:len,ngmodop:'new'+len,ngmodvar:'var'+len});
};
  $scope.hi="hi";


		 });
